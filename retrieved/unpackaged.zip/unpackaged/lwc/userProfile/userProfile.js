import { LightningElement, track } from 'lwc';

export default class UserProfile extends LightningElement {

    @track name = "";
    renderName(event){
        this.name = event.target.value;
    }
}